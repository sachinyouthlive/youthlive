package com.youthlive.youthlive;

import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Config;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    String TAG = "messageData";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        //if(remoteMessage.getData().size() > 0){

        //    Log.d("asdasd" , "asdasasdasdasd");
            //handle the data message here
        //}


        if (remoteMessage == null)
            return;

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.e(TAG, "Notification Body: " + remoteMessage.getNotification().getBody());
            handleNotification(remoteMessage.getNotification().getBody());
        }

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.e(TAG, "Data Payload: " + remoteMessage.getData().toString());

            try {
                JSONObject json = new JSONObject(remoteMessage.getData().toString());
                handleDataMessage(json);
            } catch (Exception e) {
                Log.e(TAG, "Exception: " + e.getMessage());
            }
        }


        //getting the title and the body
        //String title = remoteMessage.getNotification().getTitle();
        //String body = remoteMessage.getNotification().getBody();

        //Log.d("title" , title);
        //Log.d("body" , body);


        //Intent registrationComplete = new Intent("registrationComplete");
        //registrationComplete.putExtra("token", );
        //LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);


    }



    private void handleDataMessage(JSONObject data2) {
        Log.e(TAG, "push json: " + data2.toString());

        try {
            //JSONObject data = data2.getJSONObject("data");


            String type = data2.getString("type");
            JSONObject dat = data2.getJSONObject("data");





            if (type.equals("comment"))
            {
                Intent registrationComplete = new Intent("commentData");
                registrationComplete.putExtra("data", dat.toString());

                LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);

            }
            else if (type.equals("view"))
            {

                Log.d("view" , "called");

                Intent registrationComplete = new Intent("view");
                registrationComplete.putExtra("data", dat.toString());

                LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);
            }






        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
        }
    }



    private void handleNotification(String message) {

        Log.d("notificationData" , message);

        /*if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
            // app is in foreground, broadcast the push message
            Intent pushNotification = new Intent(Config.PUSH_NOTIFICATION);
            pushNotification.putExtra("message", message);
            LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);

            // play notification sound
            NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
            notificationUtils.playNotificationSound();
        }else{
            // If the app is in background, firebase itself handles the notification
        }*/
    }


}
