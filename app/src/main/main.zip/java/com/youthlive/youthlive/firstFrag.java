package com.youthlive.youthlive;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.ext.rtmp.RtmpDataSourceFactory;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.twilio.video.LocalAudioTrack;
import com.twilio.video.LocalVideoTrack;
import com.twilio.video.Room;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.broadcast.WZBroadcast;
import com.wowza.gocoder.sdk.api.broadcast.WZBroadcastConfig;
import com.wowza.gocoder.sdk.api.devices.WZAudioDevice;
import com.wowza.gocoder.sdk.api.devices.WZCamera;
import com.wowza.gocoder.sdk.api.devices.WZCameraView;
import com.wowza.gocoder.sdk.api.errors.WZStreamingError;
import com.wowza.gocoder.sdk.api.status.WZState;
import com.wowza.gocoder.sdk.api.status.WZStatus;
import com.wowza.gocoder.sdk.api.status.WZStatusCallback;
import com.yasic.bubbleview.BubbleView;
import com.youthlive.youthlive.INTERFACE.AllAPIs;
import com.youthlive.youthlive.followPOJO.followBean;
import com.youthlive.youthlive.getIpdatedPOJO.Comment;
import com.youthlive.youthlive.getIpdatedPOJO.getUpdatedBean;
import com.youthlive.youthlive.goLivePOJO.goLiveBean;
import com.youthlive.youthlive.liveCommentPOJO.liveCommentBean;
import com.youthlive.youthlive.requestConnectionPOJO.requestConnectionBean;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;
import veg.mediaplayer.sdk.MediaPlayer;

import static android.content.Context.MODE_PRIVATE;

public class firstFrag extends Fragment implements WZStatusCallback {

    RecyclerView grid;
    RecyclerView grid2;

    private Room room;

    LinearLayoutManager manager;
    LiveAdapter adapter;
    LiveAdapter2 adapter2;
    LinearLayoutManager manager2;
    ImageButton heart;

    //Toast toast;




    private LocalVideoTrack localVideoTrack;

    private LocalAudioTrack localAudioTrack;

    String giftURL = "", giftName = "";

    private BubbleView bubbleView;
    ImageButton close;
    ImageButton folloview_friends;
    //Broadcaster mBroadcaster;
    //SurfaceView mPreviewSurface;
    private static final String APPLICATION_ID = "gA1JdKySejF0GfA0ChIvVA";
    ListView following_friendList;
    String userId, friendid, str;
    ArrayList<String> name;
    ArrayList<String> img;
    ImageView back;
    TextView tv;

    String key = "";

    private static final int PERMISSIONS_REQUEST_CODE = 0x1;
    private boolean mPermissionsGranted = true;

    private String[] mRequiredPermissions = new String[]{
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO
    };


    // followingfriend_adapter fd;
    String url = "http://nationproducts.in/youthlive/api/follow_unfollow.php";
    RequestQueue requestQueue;
    SharedPreferences settings;




    // The GoCoder SDK camera view




    // The GoCoder SDK audio device


    // The broadcast configuration settings


    String connId;

    ProgressBar progress;



    TextView likeCount;

    String title;

    List<Comment> cList;
    List<com.youthlive.youthlive.getIpdatedPOJO.View> vList;

    String liveId = "";

    int count = 0;

    TextView viewCount;


    Integer[] gfts = {
            R.drawable.gift1,
            R.drawable.gift2,
            R.drawable.gift3,
            R.drawable.gift4,
            R.drawable.gift5,
            R.drawable.gift6
    };

    ImageButton chatIcon, switchCamera, crop;
    LinearLayout chat, actions;
    EditText comment;
    FloatingActionButton send;
    CircleImageView image;
    TextView username;

    TextView beans, level;


    LinearLayout giftLayout;
    ImageView giftIcon;
    TextView giftTitle;


    FrameLayout playerLayout1;

    String access = "";
    String sid = "";


    //SimpleExoPlayerView thumb;









    public static final String ACCOUNT_SID = "AC325e3afb64517a3f8a99b2d1133f1b3d";
    public static final String API_KEY_SID = "SKf2f5e0089874c68bb2e59cbb3b9155a2";
    public static final String API_KEY_SECRET = "1js7fkFMjVfccKAKrOpfzOIf2Lvi4Esh";
    private boolean disconnectedFromOnDestroy;
    private String TAG = "ddfsdf";


    private RtmpDataSourceFactory rtmpDataSourceFactory;
    //private VideoView player;


    //  MediaPlayerConfig wzPlayerConfig;




    BroadcastReceiver commentReceiver;
    BroadcastReceiver viewReceiver;

    LiveScreen lvscreen;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.live_pager , container , false);


        lvscreen = (LiveScreen)getActivity();


        playerLayout1 = (FrameLayout) view.findViewById(R.id.player_layout1);

        viewCount = (TextView) view.findViewById(R.id.view_count);

        giftLayout = (LinearLayout) view.findViewById(R.id.gift_layout);
        giftIcon = (ImageView) view.findViewById(R.id.gift_icon);
        giftTitle = (TextView) view.findViewById(R.id.gift_title);

        progress = (ProgressBar) view.findViewById(R.id.progress);
        chat = (LinearLayout) view.findViewById(R.id.chat);
        actions = (LinearLayout) view.findViewById(R.id.actions);
        chatIcon = (ImageButton) view.findViewById(R.id.chat_icon);
        switchCamera = (ImageButton) view.findViewById(R.id.switch_camera);
        comment = (EditText) view.findViewById(R.id.comment);
        send = (FloatingActionButton) view.findViewById(R.id.send);

        crop = (ImageButton) view.findViewById(R.id.crop);

        beans = (TextView) view.findViewById(R.id.beans);
        level = (TextView) view.findViewById(R.id.level);

        likeCount = (TextView) view.findViewById(R.id.like_count);

        image = (CircleImageView) view.findViewById(R.id.image);
        username = (TextView) view.findViewById(R.id.name);

        cList = new ArrayList<>();
        vList = new ArrayList<>();

        //mPreviewSurface = (SurfaceView) findViewById(R.id.PreviewSurfaceView);
        settings = getContext().getSharedPreferences("mypref", MODE_PRIVATE);
        userId = settings.getString("userid", "");
        folloview_friends = view.findViewById(R.id.folloview_friends);
        //mBroadcaster = new Broadcaster(this, APPLICATION_ID, mBroadcasterObserver);
        //mBroadcaster.setRotation(getWindowManager().getDefaultDisplay().getRotation());
        //mBroadcaster.setTitle(getIntent().getStringExtra("title"));
        final bean b = (bean) getContext().getApplicationContext();

        username.setText(b.userName);


        ImageLoader loader = ImageLoader.getInstance();
        loader.displayImage(b.userImage, image);


        chatIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (chat.getVisibility() == View.VISIBLE) {
                    chat.setVisibility(View.GONE);
                } else if (chat.getVisibility() == View.GONE) {
                    chat.setVisibility(View.VISIBLE);
                }

            }
        });


        switchCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lvscreen.goCoderCameraView.switchCamera();

                if (lvscreen.goCoder != null && lvscreen.goCoderCameraView != null) {
                    if (lvscreen.mAutoFocusDetector == null)
                        lvscreen.mAutoFocusDetector = new GestureDetectorCompat(getContext() , new AutoFocusListener(getContext() , lvscreen.goCoderCameraView));

                    WZCamera activeCamera = lvscreen.goCoderCameraView.getCamera();
                    if (activeCamera != null && activeCamera.hasCapability(WZCamera.FOCUS_MODE_CONTINUOUS))
                        activeCamera.setFocusMode(WZCamera.FOCUS_MODE_CONTINUOUS);
                }

            }
        });


        /*goCoderCameraView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (goCoderCameraView.getCamera().hasCapability(WZCamera.FOCUS_MODE_AUTO))
                {
                    goCoderCameraView.getCamera().setFocusMode(WZCamera.FOCUS_MODE_AUTO);
                }
                else if(goCoderCameraView.getCamera().hasCapability(WZCamera.FOCUS_MODE_CONTINUOUS))
                {
                    goCoderCameraView.getCamera().setFocusMode(WZCamera.FOCUS_MODE_CONTINUOUS);
                }
            }
        });*/







        //mBroadcaster.setAuthor(b.userImage);
        //mBroadcaster.setSendPosition(true);
        //mBroadcaster.setCustomData(b.userId);
        //mBroadcaster.setSaveOnServer(false);
        grid = (RecyclerView) view.findViewById(R.id.grid);
        grid2 = (RecyclerView) view.findViewById(R.id.grid2);
        manager = new LinearLayoutManager(getContext() , LinearLayoutManager.HORIZONTAL, false);
        manager2 = new LinearLayoutManager(getContext() , LinearLayoutManager.VERTICAL, true);
        heart = (ImageButton) view.findViewById(R.id.heart);
        folloview_friends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  follow();
            }
        });
        close = (ImageButton) view.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //mBroadcaster.stopBroadcast();
                //finish();


                lvscreen.closeConnection();




            }
        });
        heart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                bubbleView.startAnimation(bubbleView.getWidth(), bubbleView.getHeight());

            }
        });

        adapter = new LiveAdapter(getContext(), vList);
        adapter2 = new LiveAdapter2(getContext(), cList);

        grid.setAdapter(adapter);
        grid.setLayoutManager(manager);


        grid2.setAdapter(adapter2);
        grid2.setLayoutManager(manager2);


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String mess = comment.getText().toString();

                if (mess.length() > 0) {
                    progress.setVisibility(View.VISIBLE);

                    final bean b = (bean) getContext().getApplicationContext();

                    final Retrofit retrofit = new Retrofit.Builder()
                            .baseUrl(b.BASE_URL)
                            .addConverterFactory(ScalarsConverterFactory.create())
                            .addConverterFactory(GsonConverterFactory.create())
                            .build();

                    final AllAPIs cr = retrofit.create(AllAPIs.class);


                    Call<liveCommentBean> call = cr.commentLive(b.userId, liveId, mess);

                    call.enqueue(new Callback<liveCommentBean>() {
                        @Override
                        public void onResponse(Call<liveCommentBean> call, retrofit2.Response<liveCommentBean> response) {


                            if (Objects.equals(response.body().getMessage(), "Video Comment Success")) {
                                comment.setText("");
                            }

                            progress.setVisibility(View.GONE);

                        }

                        @Override
                        public void onFailure(Call<liveCommentBean> call, Throwable t) {
                            progress.setVisibility(View.GONE);
                            Log.d("Video upload find ", t.toString());
                        }
                    });
                }

            }
        });

        crop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //               HiddenShot.getInstance().buildShotAndShare(LiveScreen.this,"Check this out");

            }
        });


        bubbleView = (BubbleView) view.findViewById(R.id.bubble);
        List<Drawable> drawableList = new ArrayList<>();
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_indigo_900_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_deep_purple_900_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_cyan_900_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_blue_900_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_deep_purple_900_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_light_blue_900_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_lime_a200_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_pink_900_24dp));
        drawableList.add(getResources().getDrawable(R.drawable.ic_favorite_red_900_24dp));
        bubbleView.setDrawableList(drawableList);


        /*Timer t = new Timer();
        t.schedule(new TimerTask() {
            @Override
            public void run() {


*//*
                if (mBroadcaster.canStartBroadcasting()) {
                    mBroadcaster.startBroadcast();
                }
*//*


            }
        }, 3000);*/


        progress.setVisibility(View.VISIBLE);


        final Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(b.BASE_URL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        final AllAPIs cr = retrofit.create(AllAPIs.class);

        Call<goLiveBean> call3 = cr.goLive(b.userId, b.userId, "");

        call3.enqueue(new Callback<goLiveBean>() {
            @Override
            public void onResponse(Call<goLiveBean> call, retrofit2.Response<goLiveBean> response) {

                if (Objects.equals(response.body().getStatus(), "1")) {
                    //Toast.makeText(LiveScreen.this, "You are now live", Toast.LENGTH_SHORT).show();
                    liveId = response.body().getData().getLiveId();

                    actions.setVisibility(View.VISIBLE);


                    Log.d("liveId", liveId);
                    Log.d("userId", b.userId);


                    lvscreen.goCoderBroadcastConfig.setHostAddress("ec2-18-219-154-44.us-east-2.compute.amazonaws.com");
                    lvscreen.goCoderBroadcastConfig.setPortNumber(554);
                    lvscreen.goCoderBroadcastConfig.setApplicationName("live");
                    lvscreen.goCoderBroadcastConfig.setStreamName(liveId);



                    Log.d("keyFrame", String.valueOf(lvscreen.goCoderBroadcastConfig.getVideoKeyFrameInterval()));

                    WZStreamingError configValidationError = lvscreen.goCoderBroadcastConfig.validateForBroadcast();

                    if (configValidationError != null) {
                        //Toast.makeText(LiveScreen.this, configValidationError.getErrorDescription(), Toast.LENGTH_LONG).show();
                    } else if (lvscreen.goCoderBroadcaster.getStatus().isRunning()) {
                        // Stop the broadcast that is currently running
                        lvscreen.goCoderBroadcaster.endBroadcast(firstFrag.this);
                    } else {
                        // Start streaming
                        lvscreen.goCoderBroadcaster.startBroadcast(lvscreen.goCoderBroadcastConfig, firstFrag.this);
                    }


                    //connectToRoom("123" , "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiIsImN0eSI6InR3aWxpby1mcGE7dj0xIn0.eyJqdGkiOiJTSzM2NDRiMWZmNjkwYTM1Y2ZjOGZiNTFmYWYyMWI0NTY4LTE1MTkyOTYyODYiLCJpc3MiOiJTSzM2NDRiMWZmNjkwYTM1Y2ZjOGZiNTFmYWYyMWI0NTY4Iiwic3ViIjoiQUNmOWQwZTVhMTk4NmIxZTg2NzI0Y2I3ZmJiNjEyOTk2MCIsImV4cCI6MTUxOTI5OTg4NiwiZ3JhbnRzIjp7ImlkZW50aXR5IjoiY2xpZW50MiIsInZpZGVvIjp7InJvb20iOiIxMjMifX19.ULAQN_l_H1iEqNHM1-iNWWlk_ACs71zR1oiQDl0SGew");














                    schedule(liveId);

                } else {
                    Toast.makeText(getContext(), "Error going on live", Toast.LENGTH_SHORT).show();
                    lvscreen.finish();
                }

                progress.setVisibility(View.GONE);

            }

            @Override
            public void onFailure(Call<goLiveBean> call, Throwable t) {
                progress.setVisibility(View.GONE);
            }
        });



        commentReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                // checking for type intent filter
                if (intent.getAction().equals("commentData")) {
                    // gcm successfully registered
                    // now subscribe to `global` topic to receive app wide notifications


                    Log.d("data" , intent.getStringExtra("data"));

                    String json = intent.getStringExtra("data");

                    Gson gson = new Gson();

                    Comment item = gson.fromJson( json, Comment.class );

                    adapter2.addComment(item);

                    //displayFirebaseRegId();

                }/* else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                    // new push notification is received

                    String message = intent.getStringExtra("message");

                    Toast.makeText(getApplicationContext(), "Push notification: " + message, Toast.LENGTH_LONG).show();

                    txtMessage.setText(message);
                }*/
            }
        };



        viewReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                // checking for type intent filter
                if (intent.getAction().equals("view")) {
                    // gcm successfully registered
                    // now subscribe to `global` topic to receive app wide notifications


                    Log.d("data" , intent.getStringExtra("data"));

                    String json = intent.getStringExtra("data");

                    Gson gson = new Gson();

                    com.youthlive.youthlive.getIpdatedPOJO.View item = gson.fromJson( json, com.youthlive.youthlive.getIpdatedPOJO.View.class );

                    adapter.addView(item);

                    //displayFirebaseRegId();

                }/* else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                    // new push notification is received

                    String message = intent.getStringExtra("message");

                    Toast.makeText(getApplicationContext(), "Push notification: " + message, Toast.LENGTH_LONG).show();

                    txtMessage.setText(message);
                }*/
            }
        };


        return view;

    }




    public void schedule(final String vid) {

        Log.d("hgfjhg", vid);

        /*t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
*/
        final bean b = (bean) getContext().getApplicationContext();

        final Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(b.BASE_URL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        final AllAPIs cr = retrofit.create(AllAPIs.class);

        Log.d("VEG" , b.userId);
        Log.d("VEG" , liveId);

                /*Call<checkStatusBean> call1 = cr.checkStatus(b.userId, liveId);
                call1.enqueue(new Callback<checkStatusBean>() {
                    @Override
                    public void onResponse(Call<checkStatusBean> call, retrofit2.Response<checkStatusBean> response) {


                        try {


                            //Log.d("conId", response.body().getData().get(0).getUrl());

                            if (response.body().getData().get(0).getUrl().length() > 0)
                            {

                            //if (started) {

                                if (!playing) {


                                    MediaPlayerConfig wzPlayerConfig = new MediaPlayerConfig();


                                    //wzPlayerConfig.setConnectionUrl("rtsp://ec2-18-219-154-44.us-east-2.compute.amazonaws.com:1935/live/" + response.body().getData().get(0).getUrl());
                                    wzPlayerConfig.setConnectionUrl("rtsp://ec2-18-219-154-44.us-east-2.compute.amazonaws.com:1935/vod/sample.mp4");

                                    Log.e("url", "rtsp://ec2-18-219-154-44.us-east-2.compute.amazonaws.com:554/live/" + response.body().getData().get(0).getUrl());

                                    wzPlayerConfig.setConnectionNetworkProtocol(1);
                                    wzPlayerConfig.setConnectionDetectionTime(300);
                                    wzPlayerConfig.setConnectionBufferingTime(0);
                                    wzPlayerConfig.setConnectionBufferingSize(0);
                                    wzPlayerConfig.setDecodingType(0);
                                    wzPlayerConfig.setDecoderLatency(1);
                                    wzPlayerConfig.setNumberOfCPUCores(0);
                                    //wzPlayerConfig.setRendererType(1);
                                    wzPlayerConfig.setSynchroEnable(1);
                                    wzPlayerConfig.setSynchroNeedDropVideoFrames(0);
                                    wzPlayerConfig.setEnableAspectRatio(2);
                                    wzPlayerConfig.setDataReceiveTimeout(30000);


                                    //wzPlayerConfig.setNumberOfCPUCores(0);

                                    player.Open(wzPlayerConfig, LiveScreen.this);

                                    //player.nativePlayerSetCallback()



                                    *//*player.setVideoURI(Uri.parse("rtsp://ec2-18-219-154-44.us-east-2.compute.amazonaws.com:554/live/" + response.body().getData().get(0).getUrl()));

                                    player.requestFocus();

                                    player.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                                        @Override
                                        public void onPrepared(android.media.MediaPlayer mediaPlayer) {

                                            player.start();

                                        }
                                    });*//*





                                    playing = true;

                                }
                            //}
                            }


*//*


                                BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
                                TrackSelection.Factory videoTrackSelectionFactory =
                                        new AdaptiveTrackSelection.Factory(bandwidthMeter);
                                TrackSelector trackSelector =
                                        new DefaultTrackSelector(videoTrackSelectionFactory);


/*

                                player = ExoPlayerFactory.newSimpleInstance(LiveScreen.this , trackSelector);

                                SimpleExoPlayerView simpleExoPlayerView = (SimpleExoPlayerView) findViewById(R.id.surface);

                                simpleExoPlayerView.setPlayer(player);


                                simpleExoPlayerView.setUseController(false);
*//*


                            //if (!playing) {

                                *//*playerLayout1.setVisibility(View.VISIBLE);

                                String ur = "rtsp://ec2-18-219-154-44.us-east-2.compute.amazonaws.com:1935/sublive/" + response.body().getData().get(0).getUrl();

                                //surface.setScaleType(TextureVideoView.ScaleType.CENTER_CROP);
// Use `setDataSource` method to set data source, this could be url, assets folder or path
                                //surface.setDataSource(ur);
                                //surface.play();

                                *//**//*rtmpDataSourceFactory = new RtmpDataSourceFactory();

                                ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();
                                MediaSource videoSource = new ExtractorMediaSource(Uri.parse(ur),
                                        rtmpDataSourceFactory, extractorsFactory, null, null);
*//**//*

                                Log.d("player" , "entered");


                                MediaPlayerConfig wzPlayerConfig = new MediaPlayerConfig();


                                wzPlayerConfig.setConnectionUrl("rtsp://ec2-18-219-154-44.us-east-2.compute.amazonaws.com:1935/vod/sample.mp4");

                                wzPlayerConfig.setConnectionNetworkProtocol(1);
                                wzPlayerConfig.setConnectionDetectionTime(300);
                                wzPlayerConfig.setConnectionBufferingTime(0);
                                wzPlayerConfig.setConnectionBufferingSize(0);
                                wzPlayerConfig.setDecodingType(0);
                                wzPlayerConfig.setDecoderLatency(1);
                                wzPlayerConfig.setNumberOfCPUCores(0);
                                //wzPlayerConfig.setRendererType(1);
                                wzPlayerConfig.setSynchroEnable(1);
                                wzPlayerConfig.setSynchroNeedDropVideoFrames(0);
                                wzPlayerConfig.setEnableAspectRatio(2);
                                wzPlayerConfig.setDataReceiveTimeout(30000);
                                //wzPlayerConfig.setNumberOfCPUCores(0);


                                player.Open(wzPlayerConfig, LiveScreen.this);


                                playing = true;*//*

                            //}


                            //player.prepare(videoSource);

*//*                                player.setPlayWhenReady(true);*//*

                            //connId = response.body().getData().get(0).getId();

                        } catch (Exception e) {
                            //e.printStackTrace();

                        }


                    }

                    @Override
                    public void onFailure(Call<checkStatusBean> call, Throwable t) {

                        //Log.d("error" , t.toString());

                    }
                });
*/


        SharedPreferences fcmPref = getContext().getSharedPreferences("fcm" , Context.MODE_PRIVATE);

        String keey = fcmPref.getString("token" , "");

        Log.d("keeey" , keey);

        Call<getUpdatedBean> call = cr.getUpdatedData(b.userId, vid , keey);


        call.enqueue(new Callback<getUpdatedBean>() {
            @Override
            public void onResponse(Call<getUpdatedBean> call, retrofit2.Response<getUpdatedBean> response) {

                try {

                    adapter2.setGridData(response.body().getData().getComments());
                    adapter.setGridData(response.body().getData().getViews());

                    int count1 = Integer.parseInt(response.body().getData().getLikesCount());

                    beans.setText(response.body().getData().getBeans());
                    level.setText(response.body().getData().getLevel());


                    viewCount.setText(response.body().getData().getViewsCount());


                    if (response.body().getData().getGift().size() > 0) {
                        try {

                            giftName = response.body().getData().getGift().get(0).getGiftId();

                            showGift(Integer.parseInt(response.body().getData().getGift().get(0).getGiftId()), response.body().getData().getGift().get(0).getGiftName());

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }


                    if (count1 > count) {
                        for (int i = 0; i < count1 - count; i++)

                            bubbleView.startAnimation(bubbleView.getWidth(), bubbleView.getHeight());

                        likeCount.setText(response.body().getData().getLikesCount());

                        count = count1;
                    }




                    LocalBroadcastManager.getInstance(getContext()).registerReceiver(commentReceiver,
                            new IntentFilter("commentData"));

                    LocalBroadcastManager.getInstance(getContext()).registerReceiver(viewReceiver,
                            new IntentFilter("view"));


                } catch (Exception e) {
                    // e.printStackTrace();
                }


            }

            @Override
            public void onFailure(Call<getUpdatedBean> call, Throwable t) {

                // Log.d("asdasd", t.toString());

            }
        });

      /*      }
        }, 0, 1000);*/

    }

    public void showGift(final int pos, String title) {

        giftLayout.setVisibility(View.VISIBLE);

        Glide.with(getContext().getApplicationContext()).load(gfts[pos - 1]).into(giftIcon);
        giftTitle.setText(title);

        final Timer t = new Timer();

        t.schedule(new TimerTask() {
            @Override
            public void run() {


                giftLayout.getHandler().post(new Runnable() {
                    public void run() {
                        giftLayout.setVisibility(View.GONE);
                    }
                });

                if (t != null) {
                    t.cancel();
                }


            }
        }, 2500);


    }

    @Override
    public void onWZStatus(WZStatus wzStatus) {

    }

    @Override
    public void onWZError(WZStatus wzStatus) {

    }




/*

    public void BlockPersson(View view) {
        PersonBlock();
    }
*/





    /*@Override
    public int Status(int i) {
        Log.e("VEG", "From Native Player status: " + i);
        return 0;
    }

    @Override
    public int OnReceiveData(ByteBuffer byteBuffer, int i, long l) {
        Log.e("VEG", "Form Native Player OnReceiveData: size: " + i + ", pts: " + l);
        return 0;
    }*/

    public class LiveAdapter extends RecyclerView.Adapter<LiveAdapter.ViewHolder> {

        List<com.youthlive.youthlive.getIpdatedPOJO.View> list = new ArrayList<>();
        Context context;

        public LiveAdapter(Context context, List<com.youthlive.youthlive.getIpdatedPOJO.View> list) {
            this.context = context;
            this.list = list;
        }

        public void setGridData(List<com.youthlive.youthlive.getIpdatedPOJO.View> list) {
            this.list = list;
            notifyDataSetChanged();
        }

        public void addView(com.youthlive.youthlive.getIpdatedPOJO.View item)
        {
            list.add(0 , item);
            notifyItemInserted(0);
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(R.layout.viewers_model, parent, false);

            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {

            holder.setIsRecyclable(false);

            final com.youthlive.youthlive.getIpdatedPOJO.View item = list.get(position);

            DisplayImageOptions options = new DisplayImageOptions.Builder().cacheOnDisk(true).cacheInMemory(true).resetViewBeforeLoading(false).build();

            ImageLoader loader = ImageLoader.getInstance();

            loader.displayImage(item.getUserImage(), holder.image, options);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String uid = item.getUserId();
                    uid.replace("\"" , "");

                    Intent intent = new Intent(context, TimelineProfile.class);
                    intent.putExtra("userId", uid);
                    startActivity(intent);

                }
            });

        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            CircleImageView image;

            public ViewHolder(View itemView) {
                super(itemView);
                image = (CircleImageView) itemView.findViewById(R.id.image);

            }
        }
    }


    public class LiveAdapter2 extends RecyclerView.Adapter<LiveAdapter2.ViewHolder> {


        List<Comment> list = new ArrayList<>();
        Context context;

        public LiveAdapter2(Context context, List<Comment> list) {
            this.context = context;
            this.list = list;
        }

        public void setGridData(List<Comment> list) {
            this.list = list;
            notifyDataSetChanged();
        }


        public void addComment(Comment item)
        {
            list.add(0 , item);
            notifyItemInserted(0);
        }


        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(R.layout.chat_model, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {

            holder.setIsRecyclable(false);

            final Comment item = list.get(position);

            if (position == 0) {

                holder.name.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.gradient_white_top, 0, 0);

            } else if (position == list.size() - 1) {
                holder.name.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.gradient_white);
            } else {
                holder.name.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            }

            final String uid = item.getUserId().replace("\"" , "");

            DisplayImageOptions options = new DisplayImageOptions.Builder().cacheOnDisk(true).cacheInMemory(true).resetViewBeforeLoading(false).build();

            ImageLoader loader = ImageLoader.getInstance();

            String im = item.getUserImage().replace("\"" , "");

            loader.displayImage(im , holder.index, options);

            final bean b = (bean) context.getApplicationContext();

            String us = item.getUserName().replace("\"" , "");

            holder.user.setText(us);

            holder.index.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent = new Intent(context, TimelineProfile.class);
                    intent.putExtra("userId", uid);
                    startActivity(intent);

                }
            });



            if (Objects.equals(item.getFriendStatus().getFollow(), "true")) {
                holder.add.setBackgroundResource(R.drawable.tick);
            } else {
                holder.add.setBackgroundResource(R.drawable.plus_red);
            }

            holder.add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    Dialog dialog = new Dialog(getActivity());
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.connect_dialog);
                    dialog.setCancelable(true);
                    dialog.show();


                    CircleImageView image = (CircleImageView) dialog.findViewById(R.id.image);
                    TextView name = (TextView) dialog.findViewById(R.id.name);
                    Button follo = (Button) dialog.findViewById(R.id.follow);
                    Button connect = (Button) dialog.findViewById(R.id.connect);


                    ImageLoader loader1 = ImageLoader.getInstance();

                    loader1.displayImage(b.userImage, image);

                    name.setText(b.userName);

                    follo.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            progress.setVisibility(View.VISIBLE);

                            final bean b = (bean) context.getApplicationContext();

                            final Retrofit retrofit = new Retrofit.Builder()
                                    .baseUrl(b.BASE_URL)
                                    .addConverterFactory(ScalarsConverterFactory.create())
                                    .addConverterFactory(GsonConverterFactory.create())
                                    .build();

                            final AllAPIs cr = retrofit.create(AllAPIs.class);


                            retrofit2.Call<followBean> call = cr.follow(b.userId, uid);

                            call.enqueue(new retrofit2.Callback<followBean>() {
                                @Override
                                public void onResponse(retrofit2.Call<followBean> call, retrofit2.Response<followBean> response) {

                                    Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                                    progress.setVisibility(View.GONE);

                                }

                                @Override
                                public void onFailure(retrofit2.Call<followBean> call, Throwable t) {

                                    progress.setVisibility(View.GONE);

                                }
                            });

                        }
                    });


                    connect.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {


                            progress.setVisibility(View.VISIBLE);

                            final bean b = (bean) context.getApplicationContext();

                            final Retrofit retrofit = new Retrofit.Builder()
                                    .baseUrl(b.BASE_URL)
                                    .addConverterFactory(ScalarsConverterFactory.create())
                                    .addConverterFactory(GsonConverterFactory.create())
                                    .build();

                            final AllAPIs cr = retrofit.create(AllAPIs.class);


                            Call<requestConnectionBean> call = cr.requestConnection(liveId, b.userId, uid);

                            call.enqueue(new Callback<requestConnectionBean>() {
                                @Override
                                public void onResponse(Call<requestConnectionBean> call, retrofit2.Response<requestConnectionBean> response) {


                                    playerLayout1.setVisibility(View.VISIBLE);


                                    progress.setVisibility(View.GONE);
                                }

                                @Override
                                public void onFailure(Call<requestConnectionBean> call, Throwable t) {
                                    progress.setVisibility(View.GONE);
                                }
                            });


                        }
                    });


                }
            });





            if (Objects.equals(uid, b.userId)) {
                holder.add.setVisibility(View.GONE);
            } else {
                holder.add.setVisibility(View.VISIBLE);
            }

            String com = item.getComment().replace("\"" , "");

            holder.name.setText(com);

        }


        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView name, user;
            CircleImageView index;
            ImageButton add;

            public ViewHolder(View itemView) {
                super(itemView);

                index = (CircleImageView) itemView.findViewById(R.id.index);
                name = (TextView) itemView.findViewById(R.id.name);
                user = (TextView) itemView.findViewById(R.id.user);
                add = (ImageButton) itemView.findViewById(R.id.add);

            }
        }
    }


    @Override
    public void onPause() {

        super.onPause();

        //goCoderCameraView.stopPreview();

        //mBroadcaster.onActivityPause();
    }



    public void follow() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jObj = new JSONObject(response);
                    String status = jObj.getString("status");
                    if (!status.equals(0)) {
                        JSONObject obj2 = jObj.getJSONObject("data");
                        userId = obj2.getString("userId");
                        friendid = obj2.getString("friendId");

                    } else {
                        str = jObj.getString("message");
                        //Toast.makeText(LiveScreen.this, str, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                // hidepDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(LiveScreen.this, error.toString(), Toast.LENGTH_SHORT).show();
            }

        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                bean b = new bean();
                params.put("userId", "170");
                params.put("friendId", "19");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        mPermissionsGranted = true;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_CODE: {
                // Check the result of each permission granted
                for (int grantResult : grantResults) {
                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
                        mPermissionsGranted = false;
                    }
                }
            }
        }
    }

    //
// Utility method to check the status of a permissions request for an array of permission identifiers
//
    private static boolean hasPermissions(Context context, String[] permissions) {
        for (String permission : permissions)
            if (context.checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED)
                return false;

        return true;
    }


    @Override
    public void onStop() {
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(commentReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(viewReceiver);
        super.onStop();


        //goCoderCameraView.stopPreview();




    }


}
