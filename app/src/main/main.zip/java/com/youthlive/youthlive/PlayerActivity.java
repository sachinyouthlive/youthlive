package com.youthlive.youthlive;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.ImageViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;


import com.bambuser.broadcaster.SurfaceViewWithAutoAR;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.drm.DrmSessionManager;
import com.google.android.exoplayer2.drm.FrameworkMediaCrypto;
import com.google.android.exoplayer2.drm.UnsupportedDrmException;
import com.google.android.exoplayer2.ext.rtmp.RtmpDataSourceFactory;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.util.Util;

import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.pedro.vlc.VlcListener;
import com.pedro.vlc.VlcVideoLibrary;
import com.veer.hiddenshot.HiddenShot;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.broadcast.WZBroadcast;
import com.wowza.gocoder.sdk.api.broadcast.WZBroadcastConfig;
import com.wowza.gocoder.sdk.api.configuration.WZMediaConfig;
import com.wowza.gocoder.sdk.api.devices.WZAudioDevice;
import com.wowza.gocoder.sdk.api.devices.WZCameraView;
import com.wowza.gocoder.sdk.api.errors.WZStreamingError;
import com.wowza.gocoder.sdk.api.h264.WZProfileLevel;
import com.wowza.gocoder.sdk.api.player.WZPlayerConfig;
import com.wowza.gocoder.sdk.api.player.WZPlayerView;
import com.wowza.gocoder.sdk.api.status.WZState;
import com.wowza.gocoder.sdk.api.status.WZStatus;
import com.wowza.gocoder.sdk.api.status.WZStatusCallback;
import com.yasic.bubbleview.BubbleView;
import com.youthlive.youthlive.INTERFACE.AllAPIs;
import com.youthlive.youthlive.acceptRejectPOJO.acceptRejectBean;
import com.youthlive.youthlive.feedBackPOJO.feedBackBean;
import com.youthlive.youthlive.followPOJO.followBean;
import com.youthlive.youthlive.getConnectionPOJO.getConnectionBean;
import com.youthlive.youthlive.getIpdatedPOJO.Comment;
import com.youthlive.youthlive.getIpdatedPOJO.getUpdatedBean;
import com.youthlive.youthlive.giftPOJO.Datum;
import com.youthlive.youthlive.giftPOJO.giftBean;
import com.youthlive.youthlive.goLivePOJO.goLiveBean;
import com.youthlive.youthlive.liveCommentPOJO.liveCommentBean;
import com.youthlive.youthlive.liveLikePOJO.liveLikeBean;
import com.youthlive.youthlive.sendGiftPOJO.sendGiftBean;
import com.youthlive.youthlive.startStreamPOJO.startStreamBean;
import com.youthlive.youthlive.streamPOJO.LiveStream;
import com.youthlive.youthlive.streamPOJO.streamBean;
import com.youthlive.youthlive.streamResponsePOJO.streamResponseBean;
import com.youthlive.youthlive.vlogListPOJO.vlogListBean;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;
import veg.mediaplayer.sdk.MediaPlayerConfig;

public class PlayerActivity extends AppCompatActivity implements WZStatusCallback, VlcListener, veg.mediaplayer.sdk.MediaPlayer.MediaPlayerCallback {


    String uri;

    private WZCameraView goCoderCameraView;

    WZBroadcast goCoderBroadcaster;

    // The GoCoder SDK audio device
    private WZAudioDevice goCoderAudioDevice;

    // The broadcast configuration settings
    private WZBroadcastConfig goCoderBroadcastConfig;

    private WowzaGoCoder goCoder;

    String key;


    private RtmpDataSourceFactory rtmpDataSourceFactory;
    private SimpleExoPlayer player;

    //private VlcVideoLibrary vlcVideoLibrary;

    veg.mediaplayer.sdk.MediaPlayer surfaceView;

    MediaPlayerConfig wzPlayerConfig;

    String liveId = "";
    String timelineId = "";


    ViewPager pager;
    View popup;

    Button end;

    FragAdapter adap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        adap = new FragAdapter(getSupportFragmentManager());

        liveId = getIntent().getStringExtra("liveId");
        timelineId = getIntent().getStringExtra("timelineId");


        pager = (ViewPager)findViewById(R.id.pager);
        popup = findViewById(R.id.popup);

        end = popup.findViewById(R.id.finish);

        pager.setAdapter(adap);

        goCoder = WowzaGoCoder.init(this, "GOSK-C344-0103-177D-9E68-FCF9");

        uri = getIntent().getStringExtra("uri");

        //surface = (TextureVideoView) findViewById(R.id.surface);

        surfaceView = (veg.mediaplayer.sdk.MediaPlayer) findViewById(R.id.surface);

        //videoView = findViewById(R.id.surface);


        BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
        TrackSelection.Factory videoTrackSelectionFactory =
                new AdaptiveTrackSelection.Factory(bandwidthMeter);
        TrackSelector trackSelector =
                new DefaultTrackSelector(videoTrackSelectionFactory);


        //vlcVideoLibrary = new VlcVideoLibrary(this, this, surface);




        goCoderCameraView = (WZCameraView) findViewById(R.id.camera1);

        goCoderCameraView.setZOrderOnTop(true);

        goCoderAudioDevice = new WZAudioDevice();


        goCoderBroadcaster = new WZBroadcast();

// Create a configuration instance for the broadcaster
        goCoderBroadcastConfig = new WZBroadcastConfig(WZMediaConfig.FRAME_SIZE_176x144);

// Set the connection properties for the target Wowza Streaming Engine server or Wowza Cloud account

        //goCoderBroadcastConfig.setConnectionParameters(new WZDataMap());

// Designate the camera preview as the video source
        goCoderBroadcastConfig.setVideoBroadcaster(goCoderCameraView);


        goCoderCameraView.startPreview();

// Designate the audio device as the audio broadcaster
        goCoderBroadcastConfig.setAudioBroadcaster(goCoderAudioDevice);



        //progressDialog.show();


        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



    }







    /*BroadcastPlayer.Observer mBroadcastPlayerObserver = new BroadcastPlayer.Observer() {
        @Override
        public void onStateChange(PlayerState playerState) {
            Toast.makeText(PlayerActivity.this, playerState.toString(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onBroadcastLoaded(boolean live, int width, int height) {
        }
    };*/

    @Override
    protected void onPause() {
        super.onPause();


        if (surfaceView != null)
        {
            surfaceView.onPause();
        }

        //surface.pause();

        /*mVideoSurface = null;
        if (mBroadcastPlayer != null)
            mBroadcastPlayer.close();
        mBroadcastPlayer = null;*/
    }

    @Override
    protected void onStop() {

        super.onStop();

        if (surfaceView != null)
        {
            surfaceView.onStop();
        }


        goCoderBroadcaster.endBroadcast();

        //surface.stop();
//        player.stop();

    }



    @Override
    protected void onResume() {
        super.onResume();
        //mVideoSurface = (SurfaceView) findViewById(R.id.PreviewSurfaceView);
        //mPlayerStatusTextView.setText("Loading latest broadcast");
        //getLatestResourceUri();





        initPlayer(uri);

    }



    @Override
    public void onComplete() {
        Toast.makeText(this, "Playing", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError() {
        //vlcVideoLibrary.stop();

        //surface.stop();

        //      player.stop();

    }

    @Override
    public int Status(int i) {

        veg.mediaplayer.sdk.MediaPlayer.PlayerNotifyCodes status = veg.mediaplayer.sdk.MediaPlayer.PlayerNotifyCodes.forValue(i);

        if (status == veg.mediaplayer.sdk.MediaPlayer.PlayerNotifyCodes.PLP_CLOSE_STARTING)
        {
            if (popup.getVisibility() == View.GONE)
            {
                popup.setVisibility(View.VISIBLE);
            }
        }

        return 0;
    }

    @Override
    public int OnReceiveData(ByteBuffer byteBuffer, int i, long l) {
        return 0;
    }



    /*void getLatestResourceUri() {
        Request request = new Request.Builder()
                .url("https://api.irisplatform.io/broadcasts")
                .addHeader("Accept", "application/vnd.bambuser.v1+json")
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", "Bearer " + API_KEY)
                .get()
                .build();
        mOkHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(final Call call, final IOException e) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    if (mPlayerStatusTextView != null)
                        mPlayerStatusTextView.setText("Http exception: " + e);
                }});
            }
            @Override
            public void onResponse(final Call call, final Response response) throws IOException {
                String body = response.body().string();
                String resourceUri = null;
                try {
                    JSONObject json = new JSONObject(body);
                    JSONArray results = json.getJSONArray("results");
                    JSONObject latestBroadcast = results.optJSONObject(0);
                    resourceUri = latestBroadcast.optString("resourceUri");
                } catch (Exception ignored) {}
                final String uri = resourceUri;
                runOnUiThread(new Runnable() { @Override public void run() {
                    initPlayer(uri);
                }});
            }
        });
    }*/

    void initPlayer(String resourceUri) {


        if (resourceUri == null) {
            //if (mPlayerStatusTextView != null)
            //   mPlayerStatusTextView.setText("Could not get info about latest broadcast");
            return;
        }
        /*if (mVideoSurface == null) {
            // UI no longer active
            return;
        }

        if (mBroadcastPlayer != null)
            mBroadcastPlayer.close();
        mBroadcastPlayer = new BroadcastPlayer(this, resourceUri, APPLICATION_ID, mBroadcastPlayerObserver);


        mBroadcastPlayer.setSurfaceView(mVideoSurface);
        mBroadcastPlayer.load();*/

        /*WZPlayerConfig wzPlayerConfig = new WZPlayerConfig();

        wzPlayerConfig.setHostAddress("ec2-18-219-154-44.us-east-2.compute.amazonaws.com");
        wzPlayerConfig.setPortNumber(1935);
        wzPlayerConfig.setApplicationName("live");
        wzPlayerConfig.setStreamName(uri);
*/
        //videoView.play();





        /*videoView.play(wzPlayerConfig, new WZStatusCallback() {
            @Override
            public void onWZStatus(WZStatus wzStatus) {

                Log.d("WZStatus:  " , wzStatus.toString());

            }

            @Override
            public void onWZError(WZStatus wzStatus) {

            }
        });*/

        String ur = "rtsp://ec2-18-219-154-44.us-east-2.compute.amazonaws.com:554/live/" + resourceUri;

        //surface.setScaleType(TextureVideoView.ScaleType.CENTER_CROP);
// Use `setDataSource` method to set data source, this could be url, assets folder or path
        //surface.setDataSource(ur);
        //surface.play();


        wzPlayerConfig = new MediaPlayerConfig();


        wzPlayerConfig.setConnectionUrl(ur);

        wzPlayerConfig.setConnectionNetworkProtocol(1);
        wzPlayerConfig.setConnectionDetectionTime(300);
        wzPlayerConfig.setConnectionBufferingTime(0);
        wzPlayerConfig.setConnectionBufferingSize(0);
        wzPlayerConfig.setDecodingType(0);
        wzPlayerConfig.setDecoderLatency(1);
        wzPlayerConfig.setNumberOfCPUCores(0);
        //wzPlayerConfig.setRendererType(1);
        wzPlayerConfig.setSynchroEnable(1);
        wzPlayerConfig.setSynchroNeedDropVideoFrames(0);
        wzPlayerConfig.setEnableAspectRatio(2);
        wzPlayerConfig.setDataReceiveTimeout(30000);
        //wzPlayerConfig.setNumberOfCPUCores(0);


        surfaceView.Open(wzPlayerConfig, this);


        //wzPlayerConfig.setIsPlayback(true);



        /*wzPlayerConfig.setVideoEnabled(true);
        wzPlayerConfig.setVideoFrameWidth(640);
        wzPlayerConfig.setVideoFrameHeight(480);
        wzPlayerConfig.setVideoFramerate(30);
        wzPlayerConfig.setVideoKeyFrameInterval(30);
        wzPlayerConfig.setVideoBitRate(1500);
        wzPlayerConfig.setABREnabled(true);

        WZProfileLevel profileLevel = new WZProfileLevel(1, 1);

        if (profileLevel.validate()) {
            wzPlayerConfig.setVideoProfileLevel(profileLevel);
        }


        wzPlayerConfig.setAudioEnabled(true);

        wzPlayerConfig.setAudioSampleRate(44100);
        wzPlayerConfig.setAudioChannels(1);
        wzPlayerConfig.setAudioBitRate(64000);

*/

        /*wzPlayerConfig.setHostAddress("ec2-18-219-154-44.us-east-2.compute.amazonaws.com");
        wzPlayerConfig.setApplicationName("live");
        wzPlayerConfig.setStreamName(resourceUri);
        wzPlayerConfig.setPortNumber(1935);


        wzPlayerConfig.setVideoEnabled(true);

        //WZStreamingError configValidationError = wzPlayerConfig.validateForPlayback();

        //Log.d("Error Wowza" , configValidationError.getErrorDescription());

        //wzPlayerConfig.setHLSEnabled(true);





        if (surfaceView.isReadyToPlay())
        {



            WZStreamingError configValidationError = wzPlayerConfig.validateForPlayback();
            if (configValidationError != null) {

            } else {
                // Set the detail level for network logging output
                surfaceView.setLogLevel(2);

                // Set the player's pre-buffer duration as stored in the app prefs
                float preBufferDuration = 0;
                wzPlayerConfig.setPreRollBufferDuration(preBufferDuration);

                // Start playback of the live stream
                surfaceView.play(wzPlayerConfig, this);
            }




            wzPlayerConfig.setPreRollBufferDuration(0);

            surfaceView.setLogLevel(1);

            surfaceView.play(wzPlayerConfig , this);

            Log.d("asdasdas" , "ready_to_play");

        }
*/


        /*ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();
        MediaSource videoSource = new ExtractorMediaSource(Uri.parse(ur),
                rtmpDataSourceFactory, extractorsFactory, null, null);


        vlcVideoLibrary.play(ur);
*/

//        player.prepare(videoSource);

//        player.setPlayWhenReady(true);


        //vlcVideoLibrary.play(ur);

        /*videoView.setVideoURI(Uri.parse(ur));
        videoView.requestFocus();
        videoView.setKeepScreenOn(true);
        videoView.start();

        videoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {

                Log.d("asdasd" , "video error");

                return true;
            }
        });
*/

    }

    @Override
    public void onWZStatus(WZStatus wzStatus) {

    }

    @Override
    public void onWZError(WZStatus wzStatus) {

    }


    class StatusCallback implements WZStatusCallback {
        @Override
        public void onWZStatus(WZStatus wzStatus) {
        }

        @Override
        public void onWZError(WZStatus wzStatus) {
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        surfaceView.Close();

    }






    public class FragAdapter extends FragmentStatePagerAdapter
    {

        public FragAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            if (position == 0)
            {
                player_first pf = new player_first();
                Bundle b = new Bundle();
                b.putString("liveId" , liveId);
                b.putString("timelineId" , timelineId);
                pf.setArguments(b);
                return pf;
            }
            else
            {
                return new player_second();
            }
        }

        @Override
        public int getCount() {
            return 2;
        }
    }





}