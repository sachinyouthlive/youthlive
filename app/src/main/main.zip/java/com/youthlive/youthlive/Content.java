package com.youthlive.youthlive;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebView;
import android.widget.ProgressBar;

public class Content extends AppCompatActivity {

    Toolbar toolbar;
    WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        toolbar = (Toolbar)findViewById(R.id.toolbar);

        web = (WebView)findViewById(R.id.web);

        web.getSettings().setJavaScriptEnabled(true);
        web.loadUrl("file:///android_asset/bigo.htm");

        setSupportActionBar(toolbar);



        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrow);


        String title = getIntent().getStringExtra("title");

        toolbar.setTitle(title);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}
