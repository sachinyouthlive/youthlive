package com.youthlive.youthlive.Response;

/**
 * Created by admin on 4/18/2017.
 */
public class CoverImageResponse {
}
